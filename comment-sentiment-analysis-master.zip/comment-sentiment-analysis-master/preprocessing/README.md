

1. Chuyển text thành chữ viết thường (lowercase)
2. Sentence tokenize
3. Word tokenize
4. Kiểm tra chính tả, sửa
5. Loại bỏ các Tags
6. Loại bỏ chữ số
7. Loại bỏ dấu câu
8. Loại bỏ stopwords


# Referencies
1. https://towardsdatascience.com/text-preprocessing-for-data-scientist-3d2419c8199d