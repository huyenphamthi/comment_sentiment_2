"""
Unittests for emo
~~~~~~~~~~~~~~~~
By Neel Shah
"""

from . import *
